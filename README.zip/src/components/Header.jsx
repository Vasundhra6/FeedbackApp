
import React from 'react'
function Header()
{
    return(
    <header>
        <div className='container'>
            <h2>Vasundhra Vashist</h2>
        </div>
    </header>)
    }
export default Header

