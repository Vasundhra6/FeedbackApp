
import React from 'react'
function Footer()
{
    return(
    <footer>
        
            <h2>Panchkula</h2>
        
    </footer>)
    }
export default Footer

